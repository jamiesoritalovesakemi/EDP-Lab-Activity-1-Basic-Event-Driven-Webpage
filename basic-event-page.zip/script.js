// Select all required HTML elements using document.querySelector().
const pageContainer = document.querySelector("#pageContainer");
const mainHeading = document.querySelector("#mainHeading");
const nameInput = document.querySelector("#nameInput");
const greetingButton = document.querySelector("#greetingButton");
const backgroundButton = document.querySelector("#backgroundButton");
const resetButton = document.querySelector("#resetButton");
const messageArea = document.querySelector("#messageArea");

// Store the original page appearance.
const originalHeading = "Welcome to My Event-Driven Webpage!";
const originalBackgroundColor = "#eaf4ff";

// Event source: greetingButton
// Event listener: click
// Event handler: handleGreetingClick
function handleGreetingClick() {
    const name = nameInput.value.trim();

    if (name === "") {
        mainHeading.textContent = originalHeading;
        messageArea.textContent = "Please enter your name first.";
        console.log("Greeting button clicked with empty input.");
        return;
    }

    mainHeading.textContent = `Hello, ${name}!`;
    messageArea.textContent = `Hello, ${name}!`;
    console.log(`Greeting displayed for ${name}.`);
}

// Event source: backgroundButton
// Event listener: click
// Event handler: handleBackgroundClick
function handleBackgroundClick() {
    document.body.style.backgroundColor = "#dff7e8";
    messageArea.textContent = "The background color was changed.";
    console.log("The webpage background color was changed.");
}

// Event source: resetButton
// Event listener: click
// Event handler: handleResetClick
function handleResetClick() {
    mainHeading.textContent = originalHeading;
    nameInput.value = "";
    document.body.style.backgroundColor = originalBackgroundColor;
    messageArea.textContent = "";
    console.log("The webpage was reset.");
}

// Event source: nameInput
// Event listener: input
// Event handler: handleInput
function handleInput() {
    const currentText = nameInput.value;

    if (currentText === "") {
        messageArea.textContent = "";
    } else {
        messageArea.textContent = `You are typing: ${currentText}`;
    }

    console.log(`Current input: ${currentText}`);
}

// Event source: buttons
// Event listener: mouseover
// Event handler: handleMouseover
function handleMouseover(event) {
    const buttonName = event.currentTarget.id;
    console.log(`The mouse is over the ${buttonName}.`);
}

// Attach all event listeners using addEventListener().
greetingButton.addEventListener("click", handleGreetingClick);
backgroundButton.addEventListener("click", handleBackgroundClick);
resetButton.addEventListener("click", handleResetClick);
nameInput.addEventListener("input", handleInput);

greetingButton.addEventListener("mouseover", handleMouseover);
backgroundButton.addEventListener("mouseover", handleMouseover);
resetButton.addEventListener("mouseover", handleMouseover);

// Debugging / event monitoring.
console.log("Basic Event-Driven Webpage loaded successfully.");
